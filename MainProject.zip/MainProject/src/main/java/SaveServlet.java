import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{
	res.setContentType("text/html");
	PrintWriter pw=res.getWriter();
	int id=Integer.parseInt(req.getParameter("id"));
	String name=req.getParameter("name");
	String password=req.getParameter("password");
	String email=req.getParameter("email");
	String country=req.getParameter("country");
	
	Emp e=new Emp();
	e.setId(id);
	e.setName(name);
	e.setPassword(password);
	e.setEmail(email);
	e.setCountry(country);
	
	int status=EmpDao.save(e);
	if(status==1)
		
		pw.println("inserted successfully");
	else
		pw.println("not inserted");
		
}
}