import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet
{
public void Service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{
	res.setContentType("text/html");
	PrintWriter pw=res.getWriter();
	int id=Integer.parseInt(req.getParameter("id"));
	Emp e=new Emp();
	e=EmpDao.getEmployeeById(id);
	pw.println("<h1>Update Employee</h1>");
	pw.println("<form action='EditServlet2' method='get' ");
	pw.println("<tr><td>ID:<td><input type=text name=id value="+e.getId()+"></tr>");
	pw.println("<tr><td>Name:<td><input type=text name=name value="+e.getName()+"></tr>");
	pw.println("<tr><td>Password:<td><input type=text name=password value="+e.getPassword()+"></tr>");
	pw.println("<tr><td>Email:<td><input type=text name=email value="+e.getEmail()+"></tr>");
	pw.println("<tr><td>Country:<td><input type=text name=name value="+e.getCountry()+"></tr>");
	pw.println("</table>");
	pw.println("</form>");
		}
}