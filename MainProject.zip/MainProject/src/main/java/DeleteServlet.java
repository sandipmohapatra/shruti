import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{
	int id=Integer.parseInt(req.getParameter("id")); //html page....
	
	EmpDao.delete(id);
	res.sendRedirect("ViewServlet");
}
}