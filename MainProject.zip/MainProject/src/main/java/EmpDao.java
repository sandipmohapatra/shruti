import java.util.*;
import java.sql.*;
public class EmpDao 
{
	public static Connection getConnection()
	{
Connection con=null;
		try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
}
catch(Exception ae)
{
	ae.printStackTrace();
	}
		return con;
}
	
	//create table shruti (id number,name varchar2(30),password varchar2(30),email varchar2(30),country 
	//varchar2(30));
	public static int save(Emp ob)
	{
		int x=0;
		try
		{
		Connection con=EmpDao.getConnection();
		PreparedStatement ps=con.prepareStatement("insert into shruti values(?,?,?,?,?)");
		ps.setInt(1,ob.getId());
		ps.setString(2, ob.getName());
		ps.setString(3,ob.getPassword());
		ps.setString(4,ob.getEmail());
		ps.setString(5, ob.getCountry());
		 x=ps.executeUpdate();
	}
		catch(Exception ae)
		{}
		return x;
			}
	
	public static int update(Emp ob)
	{
		int x=0;
		try
	
	{
		Connection con=EmpDao.getConnection();
		PreparedStatement ps=con.prepareStatement("update shruti set name=?,password=?,email=?,country=? where id=?");
		
		ps.setString(1, ob.getName());
		ps.setString(2,ob.getPassword());
		ps.setString(3,ob.getEmail());
		ps.setString(4, ob.getCountry());
		ps.setInt(5,ob.getId());
		 x=ps.executeUpdate();
	}
		catch(Exception ae)
		{}
		return x;
			}
	
	public static int delete(int id)
	{
		int x=0;
		try
		{
		Connection con=EmpDao.getConnection();
		PreparedStatement ps=con.prepareStatement("delete from  shruti where id=?");
		ps.setInt(1,id);
		 x=ps.executeUpdate();
	}
		catch(Exception ae)
		{}
		return x;
			}
	
	public static Emp getEmployeeById(int id)
	{
		Emp e=new Emp();
		int x=0;
		try
		{
		Connection con=EmpDao.getConnection();
		PreparedStatement ps=con.prepareStatement("select * from  shruti where id=?");
		ps.setInt(1,id);
		 ResultSet rs=ps.executeQuery();
		 if(rs.next())
		 {
			 e.setId(rs.getInt(1));
			 e.setName(rs.getString(2));
			 e.setPassword(rs.getString(3));
			 e.setEmail(rs.getString(4));
			 e.setCountry(rs.getString(5));
		 }
	}
		catch(Exception ae)
		{}
		return e;
			}
	
	public static List<Emp> getAllEmployee()
	{
		List<Emp> list=new ArrayList<Emp>();
		try
		{
			Connection con=EmpDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from shruti");
			 ResultSet rs=ps.executeQuery();
			 while(rs.next())
			 {
				 Emp e=new Emp();
				 e.setId(rs.getInt(1));
				 e.setName(rs.getString(2));
				 e.setPassword(rs.getString(3));
				 e.setEmail(rs.getString(4));
				 e.setCountry(rs.getString(5));
				 list.add(e);
			 }
			 con.close();
		}
		catch(Exception ae)
		{		}
		return list;
	}
	
}